int sensor = 5;
int rele1 = 3;
int estado = 0;

void setup() {
  pinMode(sensor,INPUT);
  pinMode(rele1,OUTPUT);
}

void loop() {
  estado=digitalRead(sensor);
if(estado==LOW)
{
  digitalWrite(rele1,HIGH);
}
else
{
  digitalWrite(rele1,LOW);
}
}
