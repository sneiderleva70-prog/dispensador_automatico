#include <Servo.h>
#include <LiquidCrystal.h>
LiquidCrystal lcd(2, 3, 4, 5, 6, 7);
Servo servo1;
int sensor = 9;
int estado = 0; 
int ledR = 13;
int ledV = 11;

void setup() {  
  Serial.begin(9600);
  pinMode(sensor, INPUT);
  pinMode(ledR, OUTPUT);
  pinMode(ledV, OUTPUT);
  servo1.attach(8); 
  lcd.begin(16, 2);  
}   

void loop() {
  estado = digitalRead(sensor);
if (estado == LOW) 
{
  servo1.write(180);
  lcd.clear();
  lcd.setCursor(0, 1);
  lcd.print("Lavando ");
  digitalWrite(ledV,HIGH);
  digitalWrite(ledR,LOW);
  delay(1000);
  servo1.write(180);
  lcd.clear();
  lcd.setCursor(0, 1);
  lcd.print("gracias");
  digitalWrite(ledV,HIGH);
  digitalWrite(ledR,LOW);
  delay(1000);
  servo1.write(0);
  
} 
else
{
  servo1.write(0);
  lcd.clear();
  lcd.setCursor(0, 1);
  lcd.print("bienvenido");
  digitalWrite(ledV,LOW);
  digitalWrite(ledR,HIGH);
  
}
}
