int sensorR1 = 3;
int sensorR2 = 4;
int ledR1 = 5;
int ledR2 = 6;
int estadoR1 = 0;
int estadoR2 = 0;

void setup() {
  
  pinMode(ledR1,OUTPUT);
  pinMode(ledR2,OUTPUT);
  pinMode(sensorR1,INPUT);
  pinMode(sensorR2,INPUT);
}

void loop() {

  estadoR1=digitalRead(sensorR1);
  estadoR2=digitalRead(sensorR2);

if(estadoR1 == LOW and estadoR2 == HIGH)
{
  digitalWrite(ledR1,HIGH);
  digitalWrite(ledR2,LOW);
  delay(500);
}

else if(estadoR1 == LOW and estadoR2 == LOW)
{
  digitalWrite(ledR1,HIGH);
  digitalWrite(ledR2,HIGH);
  delay(500);
}

else if(estadoR1 == HIGH and estadoR2 == LOW)
{
  digitalWrite(ledR1,LOW);
  digitalWrite(ledR2,HIGH);
  delay(54400);
}

else
{
  digitalWrite(ledR1,LOW);
  digitalWrite(ledR2,LOW);
}
  
}
