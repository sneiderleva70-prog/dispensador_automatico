#include <LiquidCrystal.h>
LiquidCrystal lcd(2, 3, 4, 5, 6, 7);
void setup() {
  lcd.begin(16,2);
}

void loop() {
  lcd.setCursor(2,0);
  lcd.print("BUEN DIA");
  lcd.setCursor(5,1);
  lcd.print("MUNDO");
}
