int sensor = 11;
int rele1 = 10;
int estado = 0;

void setup() {
  pinMode(sensor, INPUT);
  pinMode(rele1, OUTPUT);
  Serial.begin(9600);

}

void loop() {
  
estado=digitalRead(sensor);
  
if(estado==LOW)
{
  digitalWrite(rele1,HIGH);
  delay(1000);
}
else
{
  digitalWrite(rele1,LOW);
}
}
