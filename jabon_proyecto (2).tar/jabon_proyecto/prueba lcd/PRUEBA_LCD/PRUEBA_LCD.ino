#include <LiquidCrystal.h>

LiquidCrystal lcd(2, 3, 4, 5, 6, 7);

void setup() {
  lcd.begin(16, 2);
}

void loop() {
  lcd.setCursor(4, 0);
  lcd.print("HOLA");

  lcd.setCursor(5, 1);
  lcd.print("MUNDO");
}
